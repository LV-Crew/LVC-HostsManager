# HostsManager
This program allows you to update your hosts file with a downloaded blacklist.<br>
The blacklisted traffic is being redirected to a blockpage (or a IP/localhost).<br>
Therefore tracking is being reduced to a minimum.<br>
You are also being protected from spam ads and more.<br>
(In short...)<br>
<br>
<br>
<h3><b>And now in long... ;-)</b></h3>
The Hosts-File-Downloader & -Updater pulls a new/updated hosts-file from any online source (URL) you want.<br>
The Hosts-Files-List is saved by the app - the update can be automated.<br>
More informations to the hosts-file can be found here: https://en.wikipedia.org/wiki/Hosts_(file)<br>
The latest manual of the HostsManager (with screenshots) can be found here: http://hostsmanager.lv-crew.org/readme.html<br>
The latest builds of the LVC-HostsManager can be downloaded here: https://github.com/LV-Crew/HostsManager/tree/master/Packages<br>
The latest release of the LVC-HostsManager can be downloaded here: https://github.com/LV-Crew/HostsManager/releases/<br>
<br>
<br>
<h3><b>What you need:</b></h3>
Microsoft Windows 7-10 or equal<br>
Microsoft .NET v4.0 or above<br>
<br>
<br>
<h3><b>Some Dev Notes:</b></h3>
https://github.com/LV-Crew/HostsManager/wiki/Some-Dev-Notes<br>
<br>
<br>
<h3><b>To-Dos & Ideas:</b></h3>
https://github.com/LV-Crew/HostsManager/wiki/To-Dos-&-Ideas-(Roadmap)<br>
<br>
<br>
<h3><b>...and more blocking...:</b></h3>
https://github.com/LV-Crew/HostsManager/wiki/More-Blocking<br>
<br>
<br>
<h3><b>...and stats:</b></h3>
https://githubstats.com/LV-Crew/HostsManager<br>
<br>
<br>
<h3><b>LV-Crew HostsManager is broth to you by:</b></h3>
- Tobias B. Besemer<br>
- Dennis M. Heine<br>
- Denis Müller<br>
- And You ???<br>
